
#ifndef LOGFACTORIAL_H
#define LOGFACTORIAL_H

#include <stdint.h>

double logfactorial(int64_t k);

#endif
