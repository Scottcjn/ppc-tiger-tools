.. _f2py-reference:

F2PY reference manual
=====================

.. toctree::
   :maxdepth: 2

   signature-file
   python-usage
   buildtools/index
   advanced/use_cases.rst
   advanced/boilerplating.rst
   f2py-testing
