.. automodule:: numpy.polynomial.chebyshev
   :no-members:
   :no-inherited-members:
   :no-special-members:
