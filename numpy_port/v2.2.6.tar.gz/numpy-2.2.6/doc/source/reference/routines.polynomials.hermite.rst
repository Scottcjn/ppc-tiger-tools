.. automodule:: numpy.polynomial.hermite
   :no-members:
   :no-inherited-members:
   :no-special-members:
