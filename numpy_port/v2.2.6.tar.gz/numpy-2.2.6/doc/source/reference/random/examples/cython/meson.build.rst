meson.build
-----------

.. literalinclude:: ../../../../../../numpy/random/_examples/cython/meson.build
    :language: python
