.. automodule:: numpy.polynomial.legendre
   :no-members:
   :no-inherited-members:
   :no-special-members:
