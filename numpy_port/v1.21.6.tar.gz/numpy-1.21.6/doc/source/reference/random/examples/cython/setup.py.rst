setup.py
--------

.. literalinclude:: ../../../../../../numpy/random/_examples/cython/setup.py
    :language: python
